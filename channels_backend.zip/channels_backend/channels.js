var channels = [
  {
    id: 1,
    name: "Backend developers",
    messages: [],
  },
  {
    id: 2,
    name: "Frontend developers",
    messages: [],
  },
  { id: 3, name: "HR managers", messages: [] },
];

module.exports = channels;
